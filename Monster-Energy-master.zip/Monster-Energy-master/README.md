# Redesign Monster Energy

<a href="https://guilhermesdb.github.io/Monster-Energy-Redesign-Tailwindcss/" target="_blank">
  <img src="src/images/capa.png" alt="image host"/>
</a> 

> Apaixonado pelos Energéticos da Monster decidi redesenhar a landing page deles, com um visual mais recente e moderno.

### Ajustes e melhorias

O projeto ainda está em desenvolvimento e as próximas atualizações serão voltadas nas seguintes tarefas:

- [ ] Novas Seções

### [Ver Preview](https://guilhermesdb.github.io/Monster-Energy/)

## 👨🏻‍💻 Techs 

 <a href="https://skillicons.dev">
    <img src="https://skillicons.dev/icons?i=html,tailwindcss,javascript" />
</a>

## 🤝 Colaboradores

Agradecemos às seguintes pessoas que contribuíram para este projeto:

<table>
  <tr>
    <td align="center">
      <a href="#">
        <img src="https://avatars.githubusercontent.com/u/66280834?v=4" width="100px;" alt="Foto de Guilherme Barros no GitHub"/><br>
        <sub>
          <b>Guilherme S Barros</b>
        </sub>
      </a>
    </td>
  </tr>
</table>

## 📝 Licença

Esse projeto está sob licença. Veja o arquivo [LICENÇA](LICENSE.md) para mais detalhes.

[⬆ Voltar ao topo](#redesign-monster-energy)<br>
